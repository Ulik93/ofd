import React from 'react'
import Equipments from '../Equipments'

export default function ControlTech(props) {
    return (
        <div>
            <Equipments data={props.data}/>
        </div>
    )
}
