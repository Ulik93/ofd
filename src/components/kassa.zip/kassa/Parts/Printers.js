import React from 'react'
import Equipments from '../Equipments'

export default function Printers(props) {
    return (
        <div>
            <Equipments data={props.data}/>
        </div>
    )
}