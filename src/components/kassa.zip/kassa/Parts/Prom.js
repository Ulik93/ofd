import React from 'react'
import Equipments from '../Equipments'

export default function Prom(props) {
    return (
        <div>
            <Equipments data={props.data}/>
        </div>
    )
}
