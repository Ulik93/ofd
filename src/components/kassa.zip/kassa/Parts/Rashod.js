import React from 'react'
import Equipments from '../Equipments'

export default function Rashod(props) {
    return (
        <div>
            <Equipments data={props.data}/>
        </div>
    )
}
