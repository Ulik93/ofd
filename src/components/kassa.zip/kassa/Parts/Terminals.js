import React from 'react'
import Equipments from '../Equipments'

export default function Terminals(props) {
    return (
        <div>
            <Equipments data={props.data}/>
        </div>
    )
}
